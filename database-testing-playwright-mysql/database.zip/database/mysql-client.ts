import mysql from 'mysql2/promise';

// Configurações fictícias de acesso ao banco de dados MySQL
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'password123',
    database: 'ecommerce_db',
    port: 3306
};

/**
 * Executa uma instrução SQL no MySQL de forma assíncrona
 * @param query Comando SQL (SELECT, INSERT, UPDATE, DELETE)
 * @param params Parâmetros para evitar vulnerabilidades de SQL Injection
 */
export async function executeQuery(query: string) {
    const connection = await mysql.createConnection({
  ...dbConfig,
});
    try {
        const [results] = await connection.query(query);
        return results;
    } catch (error) {
        console.error('Erro na execução da query no MySQL:', error);
        throw error;
    } finally {
        await connection.end(); // Garante o encerramento da conexão
    }
}
