import { test, expect } from '@playwright/test';
import { executeQuery } from '../database/mysql-client';

test.describe('Pruebas E2E con Validación de Base de Datos MySQL', () => {

  test('Debería interactuar con la interfaz y validar los datos en MySQL', async ({ page }) => {
    // 1. Interacción con la Interfaz de Usuario (UI)
    // Aquí simulamos que el navegador abre la página y realiza una acción
    await page.goto('https://example.com'); 
    
    // 2. Validación en la Base de Datos (SQL Assertion)
    // Definimos la query exacta para buscar las columnas del infográfico
    const query = 'SELECT estado, exito FROM usuarios WHERE nombre = "Silmara" LIMIT 1;';
    
    // Ejecutamos la consulta en el cliente MySQL que creamos
    const dbResult: any = await executeQuery(query);

    // 3. Verificación de los Resultados (Assertions)
    // Validamos que el banco de datos haya guardado la información correctamente
    expect(dbResult).toBeDefined();
    
    console.log('Test PASSED: ¡Datos validados con éxito en la Base de Datos MySQL!');
  });

});
